##### @Describe: 
        #  part0: data preprocess
        #  part1: build_transform() & build_dataset() & build_dataloader()
        #  part2: build_model()
        #  part3: build_loss()
        #  part4: build_metric()
        #  part5: train_one_epoch() & valid_one_epoch() & test_one_epoch()
###############################################################
import time
import numpy as np
import pdb
from tqdm import tqdm

import torch # PyTorch
from torch.utils.data import Dataset, DataLoader, TensorDataset
import torch.nn as nn

from matplotlib import pyplot as plt
from matplotlib_inline import backend_inline

def set_seed(seed=42):
    ##### why 42? The Answer to the Ultimate Question of Life, the Universe, and Everything is 42.
    # random.seed(seed) # python
    np.random.seed(seed) # numpy
    torch.manual_seed(seed) # pytorch
    # torch.cuda.manual_seed(seed)
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False

###############################################################
##### part0: data preprocess
###############################################################
def synthetic_data(w, b, num_examples):
    """Generate y = Xw + b + noise.

    Defined in :numref:`sec_linear_scratch`"""
    X = torch.normal(0, 1, (num_examples, len(w)))
    y = torch.matmul(X, w) + b
    y += torch.normal(0, 0.01, y.shape)
    return X, torch.reshape(y, (-1, 1))
def use_svg_display():
    """Use the svg format to display a plot in Jupyter.

    Defined in :numref:`sec_calculus`"""
    backend_inline.set_matplotlib_formats('svg')

def set_figsize(figsize=(3.5, 2.5)):
    """Set the figure size for matplotlib.

    Defined in :numref:`sec_calculus`"""
    use_svg_display()
    plt.rcParams['figure.figsize'] = figsize
###############################################################
##### part1: build_transforms & build_dataset & build_dataloader
###############################################################
class build_dataset(Dataset):
    def __init__(self, features, labels, is_train=True, cfg=None):

        self.features = features
        self.labels = labels
        self.is_train = is_train

    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, index):
        # pdb.set_trace()
        if self.is_train: # train
            #### load mask
            feature = self.features[index]
            label = self.labels[index]

            return feature, label


def build_dataloader(features, labels, CFG):
    # pdb.set_trace()
    train_dataset = build_dataset(features, labels, is_train=True, cfg=CFG)
    # train_dataset = TensorDataset(*(features,labels))
    train_loader = DataLoader(train_dataset, batch_size=CFG.train_bs, shuffle=True)
    
    return train_loader

###############################################################
##### >>>>>>> part2: build_model <<<<<<
###############################################################
def linreg(X, w, b):  #@save
    """线性回归模型"""
    # 此处自己添加线性回归模型
    # 此处自己用return返回估计值

def build_model(CFG):
    model = linreg
    # pdb.set_trace()   

    # 此处需要自己写代码初始化参数W和b.

    return model, W, b
###############################################################
##### >>>>>>> part3: build_loss <<<<<<
###############################################################
def squared_loss(y_hat, y):  #@save
    """均方损失"""
    # 此处需要自己写代码定义均分损失函数
    
def build_loss():
    loss = squared_loss
    return loss

def sgd(params, lr, batch_size):  #@save
    """小批量随机梯度下降"""
    with torch.no_grad():
        for param in params:
            # 此处需要自己写梯度下降代码，参数在param中。
            param.grad.zero_()
###############################################################
##### >>>>>>> part4: build_metric <<<<<<
###############################################################
    
###############################################################
##### >>>>>>> part5: train & validation & test <<<<<<
###############################################################
def train_one_epoch(model, train_loader, W, b, loss, CFG):

    losses_all = 0
    pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc='Train ')
    for _, (X, y) in pbar:
        # pdb.set_trace()
        
        y_preds = model(X, W, b) 
        mse_loss = loss(y_preds, y)        
        mse_loss.sum().backward()
        sgd([W,b], CFG.lr, CFG.train_bs)
        # pdb.set_trace()
        losses_all += mse_loss.mean()

    losses_all = losses_all / len(train_loader)
    #print("loss: {:.3f}".format(losses_all), flush=True)
    return losses_all

if __name__ == '__main__':
    ###############################################################
    ##### >>>>>>> config <<<<<<
    ###############################################################
    class CFG:
        # step1: hyper-parameter
        seed = 42  # birthday
        # step2: data
        train_bs = 10
        # step4: optimizer
        epoch = 3
        lr = 0.03

    
    set_seed(CFG.seed)

    train_val_flag = True
    if train_val_flag:
        ###############################################################
        ##### part0: data preprocess
        ###############################################################
        true_w = torch.tensor([2, -3.4])
        true_b = 4.2
        features, labels = synthetic_data(true_w, true_b, 1000)
        print('features:', features[0],'\nlabel:', labels[0])
        # set_figsize()
        # plt.scatter(features[:, 1].detach().numpy(), labels.detach().numpy(), 1)
        # plt.show()
        # pdb.set_trace()    

        ###############################################################
        ##### >>>>>>> step2: combination <<<<<<
        ##### build_transforme() & build_dataset() & build_dataloader()
        ##### build_model() & build_loss()
        ###############################################################

        train_loader = build_dataloader(features,labels, CFG) # dataset & dtaloader
        model, W, b = build_model(CFG) # model

        # optimizer = torch.optim.SGD(model.parameters(), lr=CFG.lr)
        loss = build_loss() # loss
       
        for epoch in range(1, CFG.epoch+1):
            start_time = time.time()
            ###############################################################
            ##### >>>>>>> step3: train & val <<<<<<
            ###############################################################
            losses_all = train_one_epoch(model, train_loader, W, b, loss, CFG)
               
            epoch_time = time.time() - start_time
            print("epoch:{}, loss:{:.3}\n".format(epoch, losses_all), flush=True)

        print('w的估计误差：', true_w - W.reshape(true_w.shape))

        print('b的估计误差：', true_b - b)

